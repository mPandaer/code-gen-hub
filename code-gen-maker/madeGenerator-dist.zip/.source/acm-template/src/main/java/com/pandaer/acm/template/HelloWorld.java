package com.pandaer.acm.template;

/**
 * 静态示例文件
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("hello world in acm-template-project");
    }
}
